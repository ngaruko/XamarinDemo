﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoursesLibrary
{
    public class Course
    {
        public String Title { get; internal set; }
        public String Description { get; internal set; }
        public String Image { get; internal set; }

    }
}
